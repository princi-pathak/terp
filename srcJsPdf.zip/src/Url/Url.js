 // export const API_BASE_URL = "https://siameats.com/api/";
export const API_BASE_URL = "http://192.168.1.42:5001/api/";
export const API_IMAGE_URL = "https://siameats.com/api/images/";
// export const API_IMAGE_URL = "http://192.168.1.39:5001/api/images/";
//server url https://siameats.com/api/;
// export const API_BASE_URL = "https://terp.siameats.net/api/";
// export const API_IMAGE_URL = "https://terp.siameats.net/api/images/";