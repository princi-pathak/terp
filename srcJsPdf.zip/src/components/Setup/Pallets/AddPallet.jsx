const AddPallet = () => {
	return <div>AddPallet</div>
}

export default AddPallet
