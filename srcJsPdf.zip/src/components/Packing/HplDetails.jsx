const HplDetails = () => {
	return <div>HplDetails</div>
}

export default HplDetails
