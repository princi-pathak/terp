// import { useId } from "react";
import React, { useRef } from "react";
import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
// new
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import html2canvas from "html2canvas";

// import { usePDF } from "react-to-pdf";
import axios from "axios";
import { API_BASE_URL } from "../../../Url/Url";
import logo from "../../../assets/logoNew.png";
import "./pdfView.css";
export const OrderPdfView = () => {
  const location = useLocation();
  const [companyAddress, setCompanyAddress] = useState("");
  const [result, setResult] = useState("");
  const [data, setData] = useState("");
  const [totalDetails, setTotalDetails] = useState("");
  const [tableData, setTableData] = useState([]);
  const { from } = location.state || {};
  console.log(from);
  console.log(from.order_id);
  const pdfAllData = () => {
    axios
      .post(`${API_BASE_URL}/OrderPdfDetails`, {
        order_id: from?.order_id,
      })
      .then((response) => {
        console.log(response.data);
        setCompanyAddress(response?.data?.Company_Address);
        setData(response?.data?.data);

        setTableData(response?.data?.data);
        setTotalDetails(response?.data?.totalDetails);
        setResult(response?.data?.result);
      })
      .catch((error) => {
        console.log(error);
        toast.error("Network Error", {
          autoClose: 1000,
          theme: "colored",
        });
        return false;
      });
  };

  useEffect(() => {
    pdfAllData();
  }, []);

  function formatDate(date) {
    const day = date.getDate().toString().padStart(2, "0"); // Adds leading zero if needed
    const month = (date.getMonth() + 1).toString().padStart(2, "0"); // Month is 0-based, add 1
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  }
  const tableRef = useRef();

  const handleDownloadPdf = () => {
    const input = tableRef.current;
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();

      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      const totalPages = Math.ceil(
        pdfHeight / pdf.internal.pageSize.getHeight()
      );

      for (let i = 0; i < totalPages; i++) {
        pdf.addImage(
          imgData,
          "PNG",
          0,
          -i * pdf.internal.pageSize.getHeight(),
          pdfWidth,
          pdfHeight
        );
        pdf.setFontSize(8);
        // Page number at the top right corner
        pdf.text(
          ` This documnet is  ${totalPages} Pages  (${
            i + 1
          } out of ${totalPages} )`,
          pdf.internal.pageSize.getWidth() - 57,
          4 // Adjust this value if you want it lower or higher from the top
        );
        if (i < totalPages - 1) {
          pdf.addPage();
        }
      }

      const filename = `${
        from?.Order_number || "default"
      } Operations ${formatDate(new Date())}.pdf`;
      pdf.save(filename);
    });
  };
  const newFormatter1 = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 3,
  });
  const newFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 0,
  });
  return (
    <>
      <button
        onClick={handleDownloadPdf}
        type="button"
        className="btn btn-primary"
      >
        Download
      </button>

      <div
        className="orderPdfViewWidth"
        style={{ backgroundColor: "#fff" }}
        ref={tableRef}
      >
        <table
          style={{
            width: "100%",
            paddingBottom: 30,
            padding: "15px 20px",
            display: "block",
          }}
        >
          <tbody style={{ width: "100%", display: "block" }}>
            <tr style={{ width: "100%", display: "block" }}>
              <td style={{ width: "100%", display: "block" }}>
                <table
                  style={{
                    width: "100%",
                    padding: "0px 0px 10px 0px",
                    display: "block",
                  }}
                >
                  <tbody>
                    <tr>
                      <td
                        style={{
                          width: 90,
                          padding: "0px 10px 0px 0px",
                          position: "relative",
                          top: "-25px",
                        }}
                      >
                        <img
                          style={{ height: 70 }}
                          crossorigin="anonymous"
                          src={logo}
                          alt=""
                        />
                      </td>
                      <td style={{ width: "90%", padding: "0px" }}>
                        <div style={{ display: "flex" }}>
                          <div
                            className="addressPara"
                            style={{ width: 300, padding: "0px 10px 0px 0px" }}
                          >
                            <h5 style={{ fontSize: 16, margin: "0px 0px" }}>
                              {companyAddress.Line_1}
                            </h5>
                            <p style={{ marginTop: 10 }}>
                              {companyAddress.Line_2}
                            </p>
                            <p style={{ marginTop: 10, whiteSpace: "wrap" }}>
                              {companyAddress.Line_3}
                            </p>
                            <p style={{ marginTop: 10, whiteSpace: "wrap" }}>
                              {companyAddress.Line_4}
                            </p>
                          </div>
                          <div style={{ width: "100%" }}>
                            <h5
                              style={{
                                background: "#203764",

                                paddingTop: "0px",
                                paddingBottom: "13px",
                              }}
                            >
                              <p
                                style={{
                                  position: "relative",
                                  top: "-3px",
                                  color: "#fff",
                                  textAlign: "center",
                                  fontSize: 16,
                                }}
                              >
                                {" "}
                                ออเดอร์ /โหลด
                              </p>
                            </h5>
                            <table>
                              <tbody>
                                <tr>
                                  <td style={{ padding: "0px 20px 15px 0px" }}>
                                    <div style={{ display: "flex" }}>
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          {" "}
                                          <strong>เลขออเดอร์ #</strong>{" "}
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>{from?.Order_number}</p>
                                      </div>
                                    </div>
                                    <div
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          {" "}
                                          <strong> AWB</strong>{" "}
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p> {result?.bl}</p>
                                      </div>
                                    </div>
                                    <div
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          {" "}
                                          <strong>เลขสั่งซื้อ</strong>{" "}
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>{`${from?.Shipment_ref} - ${from?.consignee_name}`}</p>
                                      </div>
                                    </div>
                                  </td>
                                  <td style={{ padding: "0px" }}>
                                    <div
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          {" "}
                                          <strong>เลขออเดอร์</strong>{" "}
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>{result?.Load_date}</p>
                                      </div>
                                    </div>
                                    <div
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>เลขสั่งซื้อ</strong>{" "}
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>{result?.Load_time}</p>
                                      </div>
                                    </div>
                                    <div
                                      style={{
                                        display: "flex",
                                        marginTop: 10,
                                        visibility: "hidden",
                                      }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          {" "}
                                          <strong>เลขสั่งซื้อ </strong>{" "}
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>O-202309045</p>
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div
                              style={{
                                marginTop: 0,
                                height: 5,
                                backgroundColor: "#203764",
                              }}
                            ></div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <table
                  className="tableBorder tableorderFirst"
                  style={{ width: "100%", padding: 10, background: "#ffff" }}
                >
                  <tbody>
                    <tr className="darkTh packingUp">
                      <th colSpan={4}>
                        <p>รายละเอียดสินค้า</p>
                      </th>
                      <th colSpan={3}>
                        <p>ออเดอร์</p>
                      </th>
                      <th colSpan={2}>
                        <p>โหลด</p>
                      </th>
                    </tr>
                    <tr>
                      <th>Packing</th>
                      <th>Boxes</th>
                      <th>Brand</th>
                      <th>ITF</th>
                      <th style={{ width: "75px" }}>EAN</th>
                      <th style={{ width: "75px" }}>Net Weight</th>
                      <th style={{ width: "60px" }}>BOXES</th>
                      <th style={{ width: "75px" }}>empty1</th>
                    </tr>

                    {tableData?.map((item) => {
                      return (
                        <tr className="orderPacking">
                          <td>
                            <p>{item.Packaging}</p>
                          </td>
                          <td>
                            <p> {item.Boxes1}</p>
                          </td>
                          <td>
                            <p>{item.Brand}</p>
                          </td>
                          <td>
                            <p>{item.itf}</p>
                          </td>
                          <td style={{ textAlign: "right" }}>
                            <p>{newFormatter1.format(item.ean_weight)}</p>
                          </td>
                          <td style={{ textAlign: "right" }}>
                            <p>{newFormatter1.format(item.Net_Weight)}</p>
                          </td>
                          <td style={{ textAlign: "right" }}>
                            <p>{newFormatter.format(item.Boxes2)}</p>
                          </td>
                          <td />
                          <td />
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
};
