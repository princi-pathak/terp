const UpdateCurrency = () => {
	return <div>UpdateCurrency</div>
}

export default UpdateCurrency
