const Claim = () => {
	return <div>Claim</div>
}

export default Claim
