import React, { useRef } from "react";
import { usePDF } from "react-to-pdf";
import { useLocation, useParams } from "react-router-dom";
import { useEffect, useId, useState } from "react";
import axios from "axios";
import barcode from "../../assets/logo.png";
import image1 from "../../assets/pic-2.jpg";
import { API_BASE_URL } from "../../Url/Url";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import html2canvas from "html2canvas";
import Barcode from "react-barcode";
const QuotaionPdf = () => {
  const [companyAddress, setCompanyAddress] = useState("");
  const [data, setData] = useState("");
  const [totalDetails, setTotalDetails] = useState("");
  const [headerData, setHeaderData] = useState("");
  const [useAgreedPricing, setUseAgreedPricing] = useState(false);
  const [itemDetails, setItemDetails] = useState(false);
  const [exchangeRate, setExchangeRate] = useState(false);

  const [cbm, setCbm] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState("Client");
  const [tableData, setTableData] = useState([]);
  const location = useLocation();
  const { from } = location.state || {};
  console.log(from);
  const pdfAllData = () => {
    axios
      .post(`${API_BASE_URL}/QuotationPDF`, {
        quotation_id: from?.quotation_id,
      })
      .then((response) => {
        console.log(response);
        setCompanyAddress(response?.data?.Company_Address);
        setData(from);

        setTableData(response?.data?.quotationDetails);
        setTotalDetails(response?.data?.quotationFinance);
        setHeaderData(response?.data?.invoice_header);
      })
      .catch((error) => {
        console.log(error);
        toast.error("Network Error", {
          autoClose: 1000,
          theme: "colored",
        });
        return false;
      });
  };
  console.log(data);
  useEffect(() => {
    pdfAllData();
  }, []);
  const handleAgreedPricingChange = (e) => {
    setUseAgreedPricing(e.target.checked);
    console.log(useAgreedPricing);
    pdfAllData();
  };
  const handleAgreedPricingChange1 = (e) => {
    setItemDetails(e.target.checked);
    console.log(itemDetails);
    pdfAllData();
  };
  const handleAgreedPricingChange2 = (e) => {
    setCbm(e.target.checked);
    console.log(cbm);
    pdfAllData();
  };

  const handleAgreedPricingChange3 = (e) => {
    setExchangeRate(e.target.checked);
    console.log(exchangeRate);
    pdfAllData();
  };
  const clearData = () => {
    setUseAgreedPricing(false);
    setItemDetails(false);
    setCbm(true);
    setExchangeRate(false);
    setSelectedInvoice("Client");
  };
  const handleRadioChange = (event) => {
    setSelectedInvoice(event.target.value);
  };
  const { id } = useParams(); // Assuming 'id' is part of the route parameters
  const tableRef = useRef();
  const submitAndCloseModal = () => {
    const input = tableRef.current;
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();

      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      const totalPages = Math.ceil(
        pdfHeight / pdf.internal.pageSize.getHeight()
      );

      for (let i = 0; i < totalPages; i++) {
        pdf.addImage(
          imgData,
          "PNG",
          0,
          -i * pdf.internal.pageSize.getHeight(),
          pdfWidth,
          pdfHeight
        );
        pdf.setFontSize(8);
        // Page number at the top right corner
        pdf.text(
          ` This document is  ${totalPages} Pages  (${
            i + 1
          } out of ${totalPages} )`,
          pdf.internal.pageSize.getWidth() - 57,
          4 // Adjust this value if you want it lower or higher from the top
        );
        if (i < totalPages - 1) {
          pdf.addPage();
        }
      }
      const filename = `${
        from?.Quotation_number || "default"
      } Quotation ${formatDate(new Date())}.pdf`;
      pdf.save(filename);
    });
    let modalElement = document.getElementById("exampleModalCustomization");
    let modalInstance = bootstrap.Modal.getInstance(modalElement);
    if (modalInstance) {
      setUseAgreedPricing(false);
      setItemDetails(false);
      setCbm(true);
      setExchangeRate(false);
      setSelectedInvoice("Client");
      modalInstance.hide();
    }
  };

  function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();

    // Add leading zeros if needed
    const formattedDay = day < 10 ? `0${day}` : day;
    const formattedMonth = month < 10 ? `0${month}` : month;
    return `${formattedDay}-${formattedMonth}-${year}`;
  }
  const formatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 0,
  });
  return (
    <div>
      <button
        className="btn btn-primary mb-4"
        type="button"
        data-bs-toggle="modal"
        data-bs-target="#exampleModalCustomization"
      >
        Download
      </button>
      <div
        className="modal fade"
        id="exampleModalCustomization"
        tabIndex={-1}
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className=" modal-dialog  modalShipTo modalInvoice">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="exampleModalLabel">
                Invoice Modal
              </h1>
              <button
                onClick={clearData}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <i class="mdi mdi-close"></i>
              </button>
            </div>
            <div className="modal-body">
              <div className="formCreate">
                <div className="row">
                  <div className="form-group col-lg-12">
                    <div className="invoiceModal d-flex justify-content-between">
                      <h6>Do you want image ? </h6>
                      <div>
                        <label
                          className="toggleSwitch large"
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            padding: 10,
                          }}
                        >
                          <input
                            type="checkbox"
                            name="Commission_Currency"
                            checked={exchangeRate}
                            onChange={handleAgreedPricingChange3}
                          />
                          <span>
                            <span>No</span>
                            <span> Yes</span>
                          </span>
                          <a> </a>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                onClick={submitAndCloseModal}
                className="btn btn-primary mb-4"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </div>
      <div style={{ width: 850 }}>
        <table
          style={{
            width: "100%",
            padding: "20px 20px",
            background: "rgb(255, 255, 255)",
            display: "block",
          }}
          ref={tableRef}
        >
          <tbody>
            <tr>
              <td style={{ padding: 0 }}>
                <table style={{ width: "100%", display: "block" }}>
                  <tbody>
                    <tr>
                      <td
                        style={{
                          width: 90,
                          padding: "0px 10px 0px 0px",
                          position: "relative",
                          top: "-17px",
                        }}
                      >
                        <img
                          crossOrigin="anonymous"
                          alt=""
                          src="https://siameats.com/api/images/logo.png"
                          style={{ height: 70, maxWidth: "unset" }}
                        />
                      </td>
                      <td style={{ width: "95%", padding: 0 }}>
                        <div style={{ display: "flex" }}>
                          <div
                            style={{
                              width: 300,
                              padding: "0px 10px 0px 0px",
                              position: "relative",
                              top: "-8px",
                            }}
                          >
                            <h5 style={{ fontSize: 16, margin: 0 }}>
                              {companyAddress?.Line_1}
                            </h5>
                            <p style={{ marginTop: 0 }}>
                              {" "}
                              {companyAddress?.Line_2}{" "}
                            </p>
                            <p
                              style={{
                                marginTop: 0,
                                whiteSpace: "normal",
                                position: "relative",
                                top: "-3px",
                              }}
                            >
                              {companyAddress?.Line_3}
                            </p>
                            <p style={{ marginTop: 0, whiteSpace: "normal" }} />
                            {companyAddress?.Line_4}
                            <p style={{ marginTop: 0, whiteSpace: "normal" }} />
                          </div>
                          <div style={{ width: "100%" }}>
                            <div
                              className="packingParent"
                              style={{
                                background: "rgb(32, 55, 100)",
                                paddingTop: 0,
                              }}
                            >
                              <h5> Quotation </h5>
                            </div>
                            <table>
                              <tbody>
                                <tr>
                                  <td style={{ padding: "0px 20px 15px 0px" }}>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex" }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Quotation </strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>{data?.Quotation_number}</p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Date </strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>{formatDate(data?.created)} </p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Valid Before</strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p /> <p>{data?.load_Before_date} </p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Min Weight</strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>{totalDetails[0]?.nw}</p>
                                      </div>
                                    </div>
                                  </td>
                                  <td style={{ padding: "0px 0px 15px 0px" }}>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong> Destination</strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p> {data?.port_name} </p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          {" "}
                                          <strong> Origin</strong>{" "}
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>Thailand</p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Liner </strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>Sellers'Choice</p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{
                                        display: "flex",
                                        marginTop: 0,
                                        paddingBottom: 0,
                                        visibility: "hidden",
                                      }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong> Delivery By</strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p> 10</p>
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div
                              style={{
                                height: 5,
                                backgroundColor: "rgb(32, 55, 100)",
                              }}
                            />
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <table style={{ width: "100%", marginTop: 5 }}>
                  <tbody>
                    <tr>
                      <td style={{ padding: 0 }}>
                        <div
                          className="ShipToParent"
                          style={{
                            display: "flex",
                            width: "100%",
                            marginBottom: 5,
                          }}
                        >
                          <div>
                            <h5>Client</h5>
                          </div>
                          <div>
                            <h5>Consignee</h5>
                          </div>
                        </div>
                        <div className="retazParent">
                          <div>
                            <p>
                              {from?.client_name} ({from?.client_tax_number}){" "}
                            </p>
                            <p>{from?.client_address} </p>
                            <p>
                              {from?.client_email} / {from?.client_phone}
                            </p>
                          </div>
                          <div>
                            <p>
                              {from?.consignee_name} (
                              {from?.consignee_tax_number})
                            </p>
                            <p>{from?.consignee_address} </p>
                            <p>
                              {" "}
                              {from?.consignee_email} / {from?.consignee_phone}
                            </p>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <table
                  className=" tableInvoiceFirst quoTable"
                  style={{ width: "100%", padding: 2 }}
                >
                  <tbody>
                    <tr className="darkTh invoiceFirst">
                      <th>
                        <p>#</p>
                      </th>
                      <th>
                        <p>Item</p>
                      </th>
                      <th>
                        <p>Scientific Name</p>
                      </th>
                      <th>
                        <p>HS Code</p>
                      </th>
                      <th style={{ textAlign: "left" }}>
                        <p>Price</p>
                      </th>
                      <th>
                        <p>Unit</p>
                      </th>
                    </tr>

                    {tableData?.map((item, index) => {
                      return (
                        <>
                          <tr>
                            <td
                              style={{
                                textAlign: "center",
                                paddingBottom: 13,
                                width: 20,
                              }}
                            >
                              <p> {index + 1}</p>
                            </td>
                            <td style={{ textAlign: "left" }}>
                              <p>{item?.ITF_Name}</p>
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <p>{item?.ITF_Scientific_name}</p>
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <p>{item?.ITF_HSCODE}</p>
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <p>{item?.quotation_price}</p>
                            </td>
                            <td style={{ textAlign: "right  " }}>
                              <p> {item?.Unit_price} </p>
                            </td>
                          </tr>
                          {exchangeRate ? (
                            <tr className="borderBot">
                              <td
                                style={{
                                  textAlign: "center",
                                  paddingBottom: 13,
                                  width: 20,
                                }}
                              >
                                1
                              </td>

                              <td style={{ textAlign: "center" }}>
                                <div className="quoImg">
                                  <img src={image1} alt="" />
                                </div>
                              </td>
                              <td style={{ textAlign: "center" }}>
                                <div className="quoImg">
                                  <img src={image1} alt="" />
                                </div>
                              </td>
                              <td style={{ textAlign: "right  " }}>
                                <div className="quoImg">
                                  <img src={image1} alt="" />
                                </div>
                              </td>
                              <td style={{ textAlign: "right" }}>
                                <div className="quoImg">
                                  <img src={image1} alt="" />
                                </div>
                              </td>

                              <td></td>
                            </tr>
                          ) : (
                            ""
                          )}
                        </>
                      );
                    })}
                  </tbody>
                </table>
                {/* <table
                                    className="totalBox"
                                    style={{ marginTop: 0, width: "100%" }}
                                >
                                    <tbody>
                                        <tr>
                                            <td style={{ padding: 0 }}>
                                                <div style={{ display: "flex" }}>
                                                    <div style={{ marginRight: "30px" }}>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    <strong>Total </strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 30 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>720</p>
                                                            </div>
                                                        </div>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    <strong>Total Packages </strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 30 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p />
                                                            </div>
                                                        </div>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    {" "}
                                                                    <strong>Total Items </strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 30 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>1</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style={{ marginLeft: 24 }}>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    <strong>Total Net Weight</strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 20 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>1440.000</p>
                                                            </div>
                                                        </div>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    {" "}
                                                                    <strong>Total Gross Weight </strong>{" "}
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 20 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>1980</p>
                                                            </div>
                                                        </div>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    <strong>Total CBM </strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 20 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>10.800</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table> */}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default QuotaionPdf;
