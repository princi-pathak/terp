import React, { useEffect } from "react";
import jsPDF from "jspdf";
import "jspdf-autotable";
import logo from "../../assets/logoT.jpg";

const ProformaInvoice = () => {
  useEffect(() => {
    const generatePdf = async () => {
      const doc = new jsPDF();

      // Convert image to base64
      const convertImageToBase64 = (url) => {
        return new Promise((resolve, reject) => {
          const img = new Image();
          img.crossOrigin = "Anonymous";
          img.src = url;
          img.onload = () => {
            const canvas = document.createElement("canvas");
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0);
            const dataURL = canvas.toDataURL("image/png");
            resolve(dataURL);
          };
          img.onerror = (error) => reject(error);
        });
      };

      // Add a logo with Proforma Address and Proforma Invoice
      const addLogoWithDetails = async () => {
        const logoData = await convertImageToBase64(logo);
        const companyAddress = {
          Line_1: "1234 Main St",
          Line_2: "City, State, ZIP",
          Line_3: "Phone: (123) 456-7890",
          Line_4: "Email: info@company.com",
        };

        const data = {
          Order_number: "123456",
          Shipment_ref: "7891011",
          load_date: "2024-07-12T00:00:00.000Z",
          Delivery_By: "N/A", // Example messageSet1 data
        };

        doc.addImage(logoData, "PNG", 15, 10, 50, 20); // Adjust the position and size as needed

        // Display company address (Proforma Address) in columns
        doc.setFontSize(10);
        doc.text(`${companyAddress.Line_1}`, 70, 15);
        doc.text(`${companyAddress.Line_2}`, 70, 20);
        doc.text(`${companyAddress.Line_3}`, 70, 25);
        doc.text(`${companyAddress.Line_4}`, 70, 30);

        // Display proforma invoice details (Proforma Invoice) in columns
        doc.setFontSize(15);
        doc.text(`Proforma Invoice: ${data.Order_number}`, 140, 10);
        doc.setFontSize(10);
        doc.text(`Order: ${data.Order_number}`, 140, 15);
        doc.text(`TT Ref: ${data.Shipment_ref}`, 140, 20);
        doc.text(`Loading Date: ${formatDate(data.load_date)}`, 140, 25);
        doc.text(`Delivery By: ${data.Delivery_By}`, 140, 30);
      };

      // Add heading and address on the left
      doc.setFontSize(18);
      doc.text('Invoice To', 15, 40);
      doc.setFontSize(12);
      doc.text('1234 Main St', 15, 50);
      doc.text('City, State, ZIP', 15, 55);
      doc.text('Phone: (123) 456-7890', 15, 60);
      doc.text('Email: info@company.com', 15, 65);

      // Add heading and address on the right
      const pageWidth = doc.internal.pageSize.getWidth();
      const rightMargin = pageWidth - 15;

      doc.setFontSize(18);
      doc.text('Consignee Details', rightMargin - doc.getTextWidth('Company Name'), 40);
      doc.setFontSize(12);
      doc.text('1234 Main St', rightMargin - doc.getTextWidth('1234 Main St'), 50);
      doc.text('City, State, ZIP', rightMargin - doc.getTextWidth('City, State, ZIP'), 55);
      doc.text('Phone: (123) 456-7890', rightMargin - doc.getTextWidth('Phone: (123) 456-7890'), 60);
      doc.text('Email: info@company.com', rightMargin - doc.getTextWidth('Email: info@company.com'), 65);

      await addLogoWithDetails(); // Wait for logo and details to be added

      // Add border lines above Proforma Address and Proforma Invoice
      doc.setLineWidth(1);
      doc.line(15, 70, 195, 70); // Horizontal line below company address section

      // Sample table data
      const columns = ["ID", "Name", "Country"];
      const rows = [
        [1, "John Doe", "USA"],
        [2, "Anna Smith", "UK"],
        [3, "Peter Jones", "Canada"],
      ];

      // Create the table
      doc.autoTable({
        head: [columns],
        body: rows,
        startY: 77, // Adjusted startY to position below the company address section
      });

      // Add bottom total details
      const totalDetails = [{
        box: 10,
        Items: 25,
        nw: "200 kg",
        gw: "250 kg",
        cbm: "5.5",
        CNF_FX: "$500"
      }];

      // Display total details in one row with three sections
      doc.setFontSize(10);
      doc.text(`Total Box: ${totalDetails[0]?.box}`, 20, 255);
      doc.text(`Total Items: ${totalDetails[0]?.Items}`, 90, 255);
      doc.text(`Total Net Weight: ${totalDetails[0]?.nw}`, 160, 255);

      doc.text(`Total Gross Weight: ${totalDetails[0]?.gw}`, 20, 262);
      doc.text(`Total CBM: ${totalDetails[0]?.cbm}`, 90, 262);

      // Add background color for Total USD CNF text
      doc.text(`Total USD CNF: ${totalDetails[0]?.CNF_FX}`, 160, 262);   

      // Add horizontal line below Total USD CNF
      doc.line(160, 265, 195, 265); // Adjusted position for the line below Total USD CNF

      // Custom page number function
      const addPageNumbers = (doc) => {
        const pageCount = doc.internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
          doc.setPage(i);
          doc.text(`Page ${i} of ${pageCount}`, 180, 290);
        }
      };

      // Add page numbers
      addPageNumbers(doc);

      // Open the PDF in a new tab
      window.open(doc.output("bloburl"));
    };

    const formatDate = (date) => {
      const d = new Date(date);
      return `${d.getDate()}-${d.getMonth() + 1}-${d.getFullYear()}`;
    };

    generatePdf(); // Generate the PDF when the component mounts
  }, []);

  return (
    <div>
      {/* You can remove the button as it's no longer needed */}
    </div>
  );
};

export default ProformaInvoice;
