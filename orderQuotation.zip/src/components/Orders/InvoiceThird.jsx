import React, { useRef } from "react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import html2canvas from "html2canvas";
// import { usePDF } from "react-to-pdf";
import { useLocation, useParams } from "react-router-dom";
import { useEffect, useId, useState } from "react";
import axios from "axios";
import barcode from "../../assets/logoT.jpg";
import logo from "../../assets/logoT.jpg";
import { API_BASE_URL } from "../../Url/Url";
import { useQuery } from "react-query";

import Barcode from "react-barcode";
const InvoiceThird = () => {
  const [messageSet1, setMassageSet1] = useState("");
  const [companyAddress, setCompanyAddress] = useState("");
  const [data, setData] = useState("");
  const [totalDetails, setTotalDetails] = useState("");
  const [headerData, setHeaderData] = useState("");
  const [useAgreedPricing, setUseAgreedPricing] = useState(false);
  const [itemDetails, setItemDetails] = useState(false);
  const [exchangeRate, setExchangeRate] = useState(false);

  const [cbm, setCbm] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState("Client");
  const [tableData, setTableData] = useState([]);
  const location = useLocation();
  const { from } = location.state || {};
  console.log(from);

  const customInvoiceDetails = () => {
    axios
      .post(`${API_BASE_URL}/InvoiceDetails`, {
        order_id: from?.order_id,
        Invoice_id: from?.Invoice_id,
      })
      .then((response) => {
        console.log(response.data.Invoice);
        setTotalDetails(response.data.Invoice);
      })
      .catch((error) => {
        console.log(error);
        toast.error("Network Error", {
          autoClose: 1000,
          theme: "colored",
        });
        return false;
      });
  };
  const pdfTableData = () => {
    axios
      .post(`${API_BASE_URL}/invoicePdfTable`, {
        invoice_id: from?.Invoice_id,
      })
      .then((response) => {
        console.log(response);

        setTableData(response.data.results);
      })
      .catch((error) => {
        console.log(error);
        toast.error("Network Error", {
          autoClose: 1000,
          theme: "colored",
        });
        return false;
      });
  };
  const pdfAllData = () => {
    axios
      .post(`${API_BASE_URL}/CustomeInvoicePdfDetails`, {
        order_id: from?.order_id,
        invoice_id: from?.Invoice_id,
      })
      .then((response) => {
        console.log(response.data);
        setCompanyAddress(response?.data?.Company_Address);
        setData(from);

        // setTableData(response.data.results);
        setHeaderData(response?.data?.invoice_header);
      })
      .catch((error) => {
        console.log(error);
        toast.error("Network Error", {
          autoClose: 1000,
          theme: "colored",
        });
        return false;
      });
  };
  console.log(data);
  useEffect(() => {
    pdfAllData();
    customInvoiceDetails();
    pdfTableData();
    delivery();
  }, []);
  const handleAgreedPricingChange = (e) => {
    setUseAgreedPricing(e.target.checked);
    console.log(useAgreedPricing);
    pdfAllData();
  };
  const handleAgreedPricingChange1 = (e) => {
    setItemDetails(e.target.checked);
    console.log(itemDetails);
    pdfAllData();
  };
  const handleAgreedPricingChange2 = (e) => {
    setCbm(e.target.checked);
    console.log(cbm);
    pdfAllData();
  };

  const handleAgreedPricingChange3 = (e) => {
    setExchangeRate(e.target.checked);
    console.log(exchangeRate);
    pdfAllData();
  };
  const clearData = () => {
    setUseAgreedPricing(false);
    setItemDetails(false);
    setCbm(true);
    setExchangeRate(false);
    setSelectedInvoice("Client");
  };
  const handleRadioChange = (event) => {
    setSelectedInvoice(event.target.value);
  };
  const { id } = useParams(); // Assuming 'id' is part of the route parameters
  // const { toPDF, targetRef } = usePDF({
  //   filename: `${from?.Invoice_number || "default"} Invoice ${formatDate(
  //     new Date()
  //   )}.pdf`,
  // });
  const tableRef = useRef();

  const submitAndCloseModal = () => {
    const input = tableRef.current;
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();

      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      const totalPages = Math.ceil(
        pdfHeight / pdf.internal.pageSize.getHeight()
      );

      for (let i = 0; i < totalPages; i++) {
        pdf.addImage(
          imgData,
          "PNG",
          0,
          -i * pdf.internal.pageSize.getHeight(),
          pdfWidth,
          pdfHeight
        );
        pdf.setFontSize(8);
        // Page number at the top right corner
        pdf.text(
          ` This documnet is  ${totalPages} Pages  (${
            i + 1
          } out of ${totalPages} )`,
          pdf.internal.pageSize.getWidth() - 57,
          4 // Adjust this value if you want it lower or higher from the top
        );
        if (i < totalPages - 1) {
          pdf.addPage();
        }
      }

      const filename = ` ${
        from?.Invoice_number || "default"
      } Invoice ${formatDate(new Date())}.pdf`;
      pdf.save(filename);
    });

    let modalElement = document.getElementById("exampleModalCustomization");
    let modalInstance = bootstrap.Modal.getInstance(modalElement);
    if (modalInstance) {
      setUseAgreedPricing(false);
      setItemDetails(false);
      setCbm(true);
      setExchangeRate(false);
      setSelectedInvoice("Client");
      modalInstance.hide();
    }
  };
  function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();

    // Add leading zeros if needed
    const formattedDay = day < 10 ? `0${day}` : day;
    const formattedMonth = month < 10 ? `0${month}` : month;
    return `${formattedDay}-${formattedMonth}-${year}`;
  }

  // Create a number formatter.
  const formatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 0,
  });
  const newFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 4,
  });
  const newFormatter1 = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 3,
  });
  const formatDate1 = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-GB"); // 'en-GB' format is DD/MM/YYYY
  };
  const delivery = () => {
    axios
      .post(`${API_BASE_URL}/pdf_delivery_by  `, {
        order_id: from?.order_id,
      })
      .then((response) => {
        console.log(response.status);
      })
      .catch((error) => {
        console.log(error);
        if (error.response.status === 400) {
          setMassageSet1(error.response.data.message);
        }
        // toast.error("Network Error", {
        //   autoClose: 1000,
        //   theme: "colored",
        // });
        return false;
      });
  };
  return (
    <div>
      {/* <button type="button" onClick={toPDF} className="btn btn-primary mb-4">
        Download
      </button> */}
      <button
        className="btn btn-primary mb-4"
        type="button"
        data-bs-toggle="modal"
        data-bs-target="#exampleModalCustomization"
      >
        Download
      </button>
      {/* modal */}
      <div
        className="modal fade"
        id="exampleModalCustomization"
        tabIndex={-1}
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className=" modal-dialog  modalShipTo modalInvoice">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="exampleModalLabel">
                Invoice Modal
              </h1>
              <button
                onClick={clearData}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <i class="mdi mdi-close"></i>
              </button>
            </div>
            <div className="modal-body">
              <div className="formCreate">
                <div className="row">
                  <div className="form-group col-lg-12">
                    <div className="invoiceModal d-flex justify-content-between">
                      <h6>Use custom name? </h6>
                      <div>
                        <label
                          className="toggleSwitch large"
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            padding: 10,
                          }}
                        >
                          <input
                            type="checkbox"
                            name="Commission_Currency"
                            checked={itemDetails}
                            onChange={handleAgreedPricingChange1}
                          />
                          <span>
                            <span>No</span>
                            <span> Yes</span>
                          </span>
                          <a> </a>
                        </label>
                      </div>
                    </div>
                    <div className="invoiceModal d-flex justify-content-between">
                      <h6>Show Gross weight and CBM ? </h6>
                      <div>
                        <label
                          className="toggleSwitch large"
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            padding: 10,
                          }}
                        >
                          <input
                            type="checkbox"
                            name="Commission_Currency"
                            checked={cbm}
                            onChange={handleAgreedPricingChange2}
                          />
                          <span>
                            <span>No</span>
                            <span> Yes</span>
                          </span>
                          <a> </a>
                        </label>
                      </div>
                    </div>

                    <div className="invoiceModal">
                      <h6>Invoice Name Can be -</h6>
                      <input
                        type="radio"
                        id="html1"
                        name="fav_language"
                        value="Client"
                        checked={selectedInvoice === "Client"}
                        onChange={handleRadioChange}
                      />
                      <label htmlFor="html1">Client</label>

                      <input
                        type="radio"
                        id="css1"
                        name="fav_language"
                        value="Consignee"
                        checked={selectedInvoice === "Consignee"}
                        onChange={handleRadioChange}
                      />
                      <label htmlFor="css1">Consignee</label>
                    </div>

                    <div className="invoiceModal d-flex justify-content-between">
                      <h6>Do you want barcode? </h6>
                      <div>
                        <label
                          className="toggleSwitch large"
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            padding: 10,
                          }}
                        >
                          <input type="checkbox" />
                          <span>
                            <span>No</span>
                            <span> Yes</span>
                          </span>
                          <a> </a>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                onClick={submitAndCloseModal}
                className="btn btn-primary mb-4"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* modal end */}
      <div
        style={{ background: "rgb(255, 255, 255)", width: 800 }}
        ref={tableRef}
      >
        <div>
          <table
            className="headerPdf"
            style={{ width: "100%", padding: 20, display: "block" }}
          >
            <tbody className="pdfCenter" style={{ width: "100%" }}>
              <tr style={{ width: "100%" }}>
                <td style={{ width: "100%", display: "block" }}>
                  <table style={{ width: "100%" }}>
                    <tbody>
                      <tr style={{ width: "100%" }}>
                        <td style={{ padding: 0, width: "100%" }}>
                          <div style={{ display: "flex", width: "100%" }}>
                            <div className="logoArea" style={{ width: 70 }}>
                              <img
                                crossOrigin="anonymous"
                                alt=""
                                src={logo}
                                style={{ height: 70 }}
                              />
                            </div>
                            <div>
                              <div className="addressPara">
                                <div style={{ padding: "0px 2px 0px 0px" }}>
                                  <h5>Siam Eats Co.,Ltd. (0395561000010)</h5>
                                  <p style={{ marginTop: 2 }}>16/8 Mu 11 </p>
                                  <p style={{ marginTop: 2 }}>
                                    Khlong Nueng, Khlong Luang, Pathum Thani
                                    12115 THAILAND
                                  </p>
                                  <p style={{ marginTop: 2 }} />
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table className="packList">
                    <tbody>
                      <tr>
                        <td
                          style={{
                            textAlign: "center",
                            fontSize: 14,
                            fontWeight: 600,
                            position: "relative",
                            top: "-3px",
                          }}
                        >
                          Packing List / Invoice
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table className="awb" style={{ width: "100%" }}>
                    <tbody>
                      <tr>
                        <td>
                          <div style={{ display: "flex" }}>
                            <div style={{ width: "100%" }}>
                              <table style={{ width: "100%" }}>
                                <tbody>
                                  <tr>
                                    <td style={{ padding: 0 }}>
                                      <div style={{ display: "flex" }}>
                                        <div
                                          className="totalSpaceBot"
                                          style={{ width: "50%" }}
                                        >
                                          <div style={{ display: "flex" }}>
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Order</strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>O-202406058</p>
                                            </div>
                                          </div>
                                          <div style={{ display: "flex" }}>
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Loading Date</strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p> </p>
                                              <p>28/06/2024</p>
                                              <p />
                                            </div>
                                          </div>
                                          <div style={{ display: "flex" }}>
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Shipment Ref</strong>{" "}
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>{data.Shipment_ref}</p>
                                            </div>
                                          </div>
                                          {/* <div style={{ display: "flex" }}>
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Customer Ref</strong>{" "}
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>{data.Customer_ref}</p>
                                            </div>
                                          </div> */}
                                          <div style={{ display: "flex" }}>
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong
                                                  style={{
                                                    color: "rgb(255, 255, 255)",
                                                  }}
                                                >
                                                  sdfdsf
                                                </strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong />
                                            </div>
                                            <div>
                                              <p
                                                style={{
                                                  color: "rgb(255, 255, 255)",
                                                }}
                                              >
                                                dfsdfsfsf
                                              </p>
                                            </div>
                                          </div>
                                        </div>
                                        <div
                                          className="totalSpaceBot"
                                          style={{ width: "50%" }}
                                        >
                                          <div style={{ display: "flex" }}>
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>AWB/BL</strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p />
                                              {data.bl}
                                            </div>
                                          </div>
                                          <div style={{ display: "flex" }}>
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Ship Date</strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p />
                                              {formatDate1(data?.Ship_date)}
                                            </div>
                                          </div>
                                          <div style={{ display: "flex" }}>
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Delivery By</strong>{" "}
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p> {messageSet1}</p>
                                            </div>
                                          </div>
                                          <div style={{ display: "flex" }}>
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong
                                                  style={{
                                                    color: "rgb(255, 255, 255)",
                                                  }}
                                                >
                                                  Delivery By
                                                </strong>{" "}
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong
                                                style={{
                                                  color: "rgb(255, 255, 255)",
                                                }}
                                              >
                                                :
                                              </strong>
                                            </div>
                                            <div>
                                              <p
                                                style={{
                                                  color: "rgb(255, 255, 255)",
                                                }}
                                              >
                                                O-202309045
                                              </p>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table className="billTo">
                    <tbody>
                      <tr>
                        <td>
                          <div style={{ display: "flex" }}>
                            <div style={{ marginRight: 10, width: 100 }}>
                              <p>
                                <strong style={{ fontWeight: 700 }}>
                                  Invoice to
                                </strong>
                              </p>
                            </div>
                          </div>
                        </td>
                        <td>
                          <div style={{ display: "flex" }}>
                            <div style={{ marginRight: 10 }}>
                              <p>
                                <strong style={{ fontWeight: 700 }}>
                                  Consignee Details
                                </strong>
                              </p>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table className="barton" style={{ width: "100%" }}>
                    <tbody>
                      <tr>
                        <td style={{ padding: 0 }}>
                          <div style={{ display: "flex", padding: 0 }}>
                            <div style={{ width: "50%", paddingRight: 5 }}>
                              <p>{data?.Client_name}</p>
                              <p>{data?.client_address}</p>
                            </div>
                            <div style={{ width: "50%" }}>
                              <p>{data?.Consignee_name}</p>
                              <p>{data?.consignee_address}</p>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table
                    className="tableBorder tableDetail"
                    style={{ width: "100%", padding: 2 }}
                  >
                    <tbody>
                      <tr className="darkTh">
                        <th style={{ textAlign: "center", width: 20 }}>
                          <p> #</p>
                        </th>
                        <th style={{ textAlign: "center" }}>
                          <p>Item Detail</p>
                        </th>
                        <th style={{ textAlign: "center" }}>
                          <p> HS Code</p>
                        </th>
                        <th style={{ textAlign: "center", width: 75 }}>
                          <p>QTY</p>
                        </th>
                        <th style={{ width: 75, textAlign: "center" }}>
                          <p>UNIT</p>
                        </th>
                        <th style={{ textAlign: "center", width: 75 }}>
                          <p>BOX</p>
                        </th>
                        <th style={{ textAlign: "center", width: 85 }}>
                          <p>FOB (THB)</p>
                        </th>
                      </tr>
                      {tableData?.map((item, i) => {
                        return (
                          <tr className="itemData">
                            <td style={{ textAlign: "center" }}>
                              <p> {i + 1}</p>
                            </td>
                            <td>
                              <p> {item.itf_th}</p>
                            </td>
                            <td style={{ textAlign: "right" }}>
                              <p>{item.HS_CODE}</p>
                            </td>
                            <td style={{ textAlign: "right" }}>
                              <p>
                                {" "}
                                <p> {newFormatter1.format(item.Net_Weight)}</p>
                              </p>
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <p> KG</p>
                            </td>
                            <td style={{ textAlign: "right" }}>
                              <p> {item.Boxes}</p>
                            </td>
                            <td style={{ textAlign: "right" }}>
                              <p>{newFormatter.format(item.FOB)}</p>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  <table style={{ marginTop: 5, width: "100%" }}>
                    <tbody>
                      <tr>
                        <td style={{ padding: 0 }}>
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            <div className="totalSpaceBot">
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 115 }}>
                                  <p>
                                    <strong>Total </strong>
                                  </p>
                                </div>
                                <div style={{ width: 30 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>
                                    {totalDetails?.box} Boxes /
                                    {totalDetails?.Items} Item{" "}
                                  </p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 115 }}>
                                  <p>
                                    <strong>Total Net Weight </strong>{" "}
                                  </p>
                                </div>
                                <div style={{ width: 30 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>
                                    {formatter.format(totalDetails?.nw)}{" "}
                                    Kg
                                  </p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 115 }}>
                                  <p>
                                    <strong>Total Gross Weight </strong>
                                  </p>
                                </div>
                                <div style={{ width: 30 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>
                                    {formatter.format(
                                      totalDetails?.gw
                                    )}{" "}
                                    Kg
                                  </p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 115 }}>
                                  <p>
                                    <strong>Total CBM </strong>
                                  </p>
                                </div>
                                <div style={{ width: 30 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>{totalDetails?.cbm}</p>
                                </div>
                              </div>
                            </div>
                            <div
                              className="totalSpaceBot"
                              style={{ marginLeft: 10 }}
                            >
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 90 }}>
                                  <p>
                                    <strong>Total Packages</strong>
                                  </p>
                                </div>
                                <div style={{ width: 20 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p> {from?.packages}</p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 90 }}>
                                  <p>
                                    <strong>FOB (THB) </strong>
                                  </p>
                                </div>
                                <div style={{ width: 20 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>{formatter.format(totalDetails?.FOB)}</p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 90 }}>
                                  <p>
                                    <strong>Air Freight </strong>
                                  </p>
                                </div>
                                <div style={{ width: 20 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>
                                    {formatter.format(totalDetails?.freight)}
                                  </p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 90 }}>
                                  <p>
                                    <strong>Exchange Rate </strong>
                                  </p>
                                </div>
                                <div style={{ width: 20 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>{from?.fx_rate}</p>
                                </div>
                              </div>
                            </div>
                            <div>
                              <div
                                style={{ position: "relative", top: "-3px" }}
                              >
                                <table className="unsetAll">
                                  <tbody>
                                    <tr>
                                      <td>
                                        <div className="toatalThbTwo">
                                          <div>
                                            <strong>Total THB</strong>
                                          </div>
                                          <div>
                                            <p>
                                              {" "}
                                              {formatter.format(totalDetails?.CNF)}
                                            </p>
                                          </div>
                                        </div>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                              <div style={{ marginTop: "-7px" }}>
                                <table className="unsetAll">
                                  <tbody>
                                    <tr>
                                      <td
                                        style={{ color: "rgb(255, 255, 255)" }}
                                      >
                                        <div className="toatalThbTwo">
                                          <div>
                                            <strong>
                                              Total USD
                                              {/* {
                                                allData?.currencyResults
                                                  ?.currency
                                              } */}
                                            </strong>
                                          </div>
                                          <div>
                                            <p>
                                              {" "}
                                              {formatter.format(
                                                totalDetails?.CNF_FX
                                              )}
                                            </p>
                                          </div>
                                        </div>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default InvoiceThird;
