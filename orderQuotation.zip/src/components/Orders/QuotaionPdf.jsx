import React, { useRef } from "react";
import { usePDF } from "react-to-pdf";
import { useLocation, useParams } from "react-router-dom";
import { useEffect, useId, useState } from "react";
import axios from "axios";
import barcode from "../../assets/logo.png";
import image1 from "../../assets/pic-2.jpg";
import { API_BASE_URL } from "../../Url/Url";
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';
import Barcode from "react-barcode";
const QuotaionPdf = () => {
  const [companyAddress, setCompanyAddress] = useState("");
  const [data, setData] = useState("");
  const [totalDetails, setTotalDetails] = useState("");
  const [headerData, setHeaderData] = useState("");
  const [useAgreedPricing, setUseAgreedPricing] = useState(false);
  const [itemDetails, setItemDetails] = useState(false);
  const [exchangeRate, setExchangeRate] = useState(false);

  const [cbm, setCbm] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState("Client");
  const [tableData, setTableData] = useState([]);
  const location = useLocation();
  const { from } = location.state || {};
  console.log(from);
  const pdfAllData = () => {
    axios
      .post(`${API_BASE_URL}/InvoicePdfDetails`, {
        order_id: from?.order_id,
        invoice_id: from?.Invoice_id,
      })
      .then((response) => {
        console.log(response.data);
        setCompanyAddress(response?.data?.Company_Address);
        setData(from);

        setTableData(response?.data?.InvoiceDetails);
        setTotalDetails(response?.data?.TotalDetails);
        setHeaderData(response?.data?.invoice_header);
      })
      .catch((error) => {
        console.log(error);
        toast.error("Network Error", {
          autoClose: 1000,
          theme: "colored",
        });
        return false;
      });
  };
  console.log(data);
  useEffect(() => {
    pdfAllData();
  }, []);
  const handleAgreedPricingChange = (e) => {
    setUseAgreedPricing(e.target.checked);
    console.log(useAgreedPricing);
    pdfAllData();
  };
  const handleAgreedPricingChange1 = (e) => {
    setItemDetails(e.target.checked);
    console.log(itemDetails);
    pdfAllData();
  };
  const handleAgreedPricingChange2 = (e) => {
    setCbm(e.target.checked);
    console.log(cbm);
    pdfAllData();
  };

  const handleAgreedPricingChange3 = (e) => {
    setExchangeRate(e.target.checked);
    console.log(exchangeRate);
    pdfAllData();
  };
  const clearData = () => {
    setUseAgreedPricing(false);
    setItemDetails(false);
    setCbm(true);
    setExchangeRate(false);
    setSelectedInvoice("Client");
  };
  const handleRadioChange = (event) => {
    setSelectedInvoice(event.target.value);
  };
  const { id } = useParams(); // Assuming 'id' is part of the route parameters
  const tableRef = useRef();
  const handleDownloadPdf = () => {
    const input = tableRef.current;
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();

      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      const totalPages = Math.ceil(pdfHeight / pdf.internal.pageSize.getHeight());

      for (let i = 0; i < totalPages; i++) {
        pdf.addImage(
          imgData,
          "PNG",
          0,
          -i * pdf.internal.pageSize.getHeight(),
          pdfWidth,
          pdfHeight
        );
        pdf.setFontSize(8);
        // Page number at the top right corner
        pdf.text(
          ` This documnet is  ${totalPages} Pages  (${i + 1} out of ${totalPages} )`,
          pdf.internal.pageSize.getWidth() - 57,
          4 // Adjust this value if you want it lower or higher from the top
        );
        if (i < totalPages - 1) {
          pdf.addPage();
        }
      }

      const filename = `Quotation${new Date().toLocaleDateString()}.pdf`;
      pdf.save(filename);
    });
  };

  function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();

    // Add leading zeros if needed
    const formattedDay = day < 10 ? `0${day}` : day;
    const formattedMonth = month < 10 ? `0${month}` : month;
    return `${formattedDay}-${formattedMonth}-${year}`;
  }
  const formatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 0,
  });
  return (
    <div>
      <button
        className="btn btn-primary mb-4"
        type="button"
        onClick={handleDownloadPdf}
      >
        Download
      </button>
      {/* modal */}

      {/* modal end */}
      <div style={{ width: 850 }}>
        <table
          style={{
            width: "100%",
            padding: "20px 20px",
            background: "rgb(255, 255, 255)",
            display: "block",
          }}
          ref={tableRef}
        >
          <tbody>
            <tr>
              <td style={{ padding: 0 }}>
                <table style={{ width: "100%", display: "block" }}>
                  <tbody>
                    <tr>
                      <td
                        style={{
                          width: 90,
                          padding: "0px 10px 0px 0px",
                          position: "relative",
                          top: "-17px",
                        }}
                      >
                        <img
                          crossOrigin="anonymous"
                          alt=""
                          src="https://siameats.com/api/images/logo.png"
                          style={{ height: 70, maxWidth: "unset" }}
                        />
                      </td>
                      <td style={{ width: "95%", padding: 0 }}>
                        <div style={{ display: "flex" }}>
                          <div
                            style={{
                              width: 300,
                              padding: "0px 10px 0px 0px",
                              position: "relative",
                              top: "-8px",
                            }}
                          >
                            <h5 style={{ fontSize: 16, margin: 0 }}>
                              Siam Eats Co.,Ltd. (0395561000010)
                            </h5>
                            <p style={{ marginTop: 0 }}>16/8 Mu 11 </p>
                            <p
                              style={{
                                marginTop: 0,
                                whiteSpace: "normal",
                                position: "relative",
                                top: "-3px",
                              }}
                            >
                              Khlong Nueng, Khlong Luang, Pathum Thani 12120
                              THAILAND
                            </p>
                            <p style={{ marginTop: 0, whiteSpace: "normal" }} />
                            <p style={{ marginTop: 0, whiteSpace: "normal" }} />
                          </div>
                          <div style={{ width: "100%" }}>
                            <div
                              className="packingParent"
                              style={{
                                background: "rgb(32, 55, 100)",
                                paddingTop: 0,
                              }}
                            >
                              <h5>  Quotation </h5>
                            </div>
                            <table>
                              <tbody>
                                <tr>
                                  <td style={{ padding: "0px 20px 15px 0px" }}>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex" }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Quotation </strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>O-202405079</p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Date </strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>12/6/2023</p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Valid Before</strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p />
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Min Weight</strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>12.00</p>
                                      </div>
                                    </div>
                                  </td>
                                  <td style={{ padding: "0px 0px 15px 0px" }}>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong> Destination</strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>South Africa</p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          {" "}
                                          <strong> Origin</strong>{" "}
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>xyz</p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{ display: "flex", marginTop: 0 }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong>Liner </strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p>Air</p>
                                      </div>
                                    </div>
                                    <div
                                      className="totalSpaceBot"
                                      style={{
                                        display: "flex",
                                        marginTop: 0,
                                        paddingBottom: 0,
                                        visibility: "hidden",
                                      }}
                                    >
                                      <div
                                        style={{ marginRight: 10, width: 100 }}
                                      >
                                        <p>
                                          <strong> Delivery By</strong>
                                        </p>
                                      </div>
                                      <div style={{ width: 10 }}>
                                        <strong>:</strong>
                                      </div>
                                      <div>
                                        <p> 10</p>
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div
                              style={{
                                height: 5,
                                backgroundColor: "rgb(32, 55, 100)",
                              }}
                            />
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <table style={{ width: "100%", marginTop: 5 }}>
                  <tbody>
                    <tr>
                      <td style={{ padding: 0 }}>
                        <div
                          className="ShipToParent"
                          style={{
                            display: "flex",
                            width: "100%",
                            marginBottom: 5,
                          }}
                        >
                          <div>
                            <h5>Client</h5>
                          </div>
                          <div>
                            <h5>Consignee</h5>
                          </div>
                        </div>
                        <div className="retazParent">
                          <div>
                            <p>HLB Tropical Food GmbH</p>
                            <p>Am Weiher 2a 65451 Kelsterbach Germany</p>
                          </div>
                          <div>
                            <p>Costco Wholesale UK Ltd</p>
                            <p>
                              Hartspring Lane Watford Herts WD25 8JS United
                              Kingdom
                            </p>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <table
                  className=" tableInvoiceFirst quoTable"
                  style={{ width: "100%", padding: 2 }}
                >
                  <tbody>
                    <tr className="darkTh invoiceFirst">
                      <th>
                        <p>#</p>
                      </th>
                      <th>
                        <p>Item</p>
                      </th>
                      <th>
                        <p>Scientific Name</p>
                      </th>
                      <th>
                        <p>HS Code</p>
                      </th>
                      <th style={{ textAlign: "left" }}>
                        <p>Price</p>
                      </th>
                      <th>
                        <p>Unit</p>
                      </th>
                    </tr>
                    <tr>
                      <td
                        style={{
                          textAlign: "center",
                          paddingBottom: 13,
                          width: 20,
                        }}
                      >
                        1
                      </td>
                      <td style={{ textAlign: "left" }}>
                        <p>1440.000</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> Moringa oleifera</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> 182320</p>
                      </td>
                      <td style={{ textAlign: "right  " }}>
                        <p> {formatter.format(14642.34)}</p>
                      </td>
                      <td style={{ textAlign: "right" }}>
                        <p>USD / Kg</p>
                      </td>
                    </tr>
                    <tr className="borderBot">
                      <td
                        style={{
                          textAlign: "center",
                          paddingBottom: 13,
                          width: 20,
                        }}
                      >
                        1
                      </td>

                      <td style={{ textAlign: "center" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "right  " }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "right" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>

                      <td></td>
                    </tr>
                    <tr>
                      <td
                        style={{
                          textAlign: "center",
                          paddingBottom: 13,
                          width: 20,
                        }}
                      >
                        1
                      </td>
                      <td style={{ textAlign: "left" }}>
                        <p>1440.000</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> Moringa oleifera</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> 182320</p>
                      </td>
                      <td style={{ textAlign: "right  " }}>
                        <p> {formatter.format(15642.34)}</p>
                      </td>

                      <td style={{ textAlign: "right" }}>
                        <p>USD / Kg</p>
                      </td>
                    </tr>
                    <tr className="borderBot">
                      <td
                        style={{
                          textAlign: "center",
                          paddingBottom: 13,
                          width: 20,
                        }}
                      >
                        1
                      </td>

                      <td style={{ textAlign: "center" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "right  " }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "right" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>

                      <td></td>
                    </tr>
                    <tr>
                      <td
                        style={{
                          textAlign: "center",
                          paddingBottom: 13,
                          width: 20,
                        }}
                      >
                        1
                      </td>
                      <td style={{ textAlign: "left" }}>
                        <p>1440.000</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> Moringa oleifera</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> 182320</p>
                      </td>
                      <td style={{ textAlign: "right  " }}>
                        <p> {formatter.format(1642.34)}</p>
                      </td>
                      <td style={{ textAlign: "right" }}>
                        <p>USD / Kg</p>
                      </td>
                    </tr>
                    <tr className="borderBot">
                      <td
                        style={{
                          textAlign: "center",
                          paddingBottom: 13,
                          width: 20,
                        }}
                      >
                        1
                      </td>

                      <td style={{ textAlign: "center" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "right  " }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "right" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>

                      <td></td>
                    </tr>
                    <tr>
                      <td
                        style={{
                          textAlign: "center",
                          paddingBottom: 13,
                          width: 20,
                        }}
                      >
                        1
                      </td>
                      <td style={{ textAlign: "left" }}>
                        <p>1440.000</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> Moringa oleifera</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> 182320</p>
                      </td>
                      <td style={{ textAlign: "right  " }}>
                        <p> {formatter.format(1242.34)}</p>
                      </td>
                      <td style={{ textAlign: "right" }}>
                        <p>USD / Kg</p>
                      </td>
                    </tr>
                    <tr className=" ">
                      <td
                        style={{
                          textAlign: "center",
                          paddingBottom: 13,
                          width: 20,
                        }}
                      >
                        1
                      </td>

                      <td style={{ textAlign: "center" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "right  " }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>
                      <td style={{ textAlign: "right" }}>
                        <div className="quoImg">
                          <img src={image1} alt="" />
                        </div>
                      </td>

                      <td></td>
                    </tr>
                    <tr>
                      <td
                        style={{
                          textAlign: "center",
                          paddingBottom: 13,
                          width: 20,
                        }}
                      >
                        1
                      </td>
                      <td style={{ textAlign: "left" }}>
                        <p>1440.000</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> Moringa oleifera</p>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <p> 182320</p>
                      </td>
                      <td style={{ textAlign: "right  " }}>
                        <p> {formatter.format(1042.34)}</p>
                      </td>
                      <td style={{ textAlign: "right" }}>
                        <p>USD / Kg</p>
                      </td>
                    </tr>
                    {/* <tr>
                                            <td
                                                style={{
                                                    textAlign: "center",
                                                    paddingBottom: 13,
                                                    width: 20,
                                                }}
                                            >
                                                1
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>1440.000</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p> Moringa oleifera</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p> 182320</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p>12</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>Kg</p>
                                            </td>
                                             
                                        </tr>
                                        <tr>
                                            <td
                                                style={{
                                                    textAlign: "center",
                                                    paddingBottom: 13,
                                                    width: 20,
                                                }}
                                            >
                                                1
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>1440.000</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p> Moringa oleifera</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p> 182320</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p>12</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>Kg</p>
                                            </td>
                                             
                                        </tr>
                                        <tr>
                                            <td
                                                style={{
                                                    textAlign: "center",
                                                    paddingBottom: 13,
                                                    width: 20,
                                                }}
                                            >
                                                1
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>1440.000</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p> Moringa oleifera</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p> 182320</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p>12</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>Kg</p>
                                            </td>
                                             
                                        </tr>
                                        <tr>
                                            <td
                                                style={{
                                                    textAlign: "center",
                                                    paddingBottom: 13,
                                                    width: 20,
                                                }}
                                            >
                                                1
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>1440.000</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p> Moringa oleifera</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p> 182320</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p>12</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>Kg</p>
                                            </td>
                                             
                                        </tr>
                                        <tr>
                                            <td
                                                style={{
                                                    textAlign: "center",
                                                    paddingBottom: 13,
                                                    width: 20,
                                                }}
                                            >
                                                1
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>1440.000</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p> Moringa oleifera</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p> 182320</p>
                                            </td>
                                            <td style={{ textAlign: "left" }}>
                                                <p>12</p>
                                            </td>
                                            <td style={{ textAlign: "right" }}>
                                                <p>Kg</p>
                                            </td>
                                             
                                        </tr> */}
                  </tbody>
                </table>
                {/* <table
                                    className="totalBox"
                                    style={{ marginTop: 0, width: "100%" }}
                                >
                                    <tbody>
                                        <tr>
                                            <td style={{ padding: 0 }}>
                                                <div style={{ display: "flex" }}>
                                                    <div style={{ marginRight: "30px" }}>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    <strong>Total </strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 30 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>720</p>
                                                            </div>
                                                        </div>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    <strong>Total Packages </strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 30 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p />
                                                            </div>
                                                        </div>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    {" "}
                                                                    <strong>Total Items </strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 30 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>1</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style={{ marginLeft: 24 }}>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    <strong>Total Net Weight</strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 20 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>1440.000</p>
                                                            </div>
                                                        </div>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    {" "}
                                                                    <strong>Total Gross Weight </strong>{" "}
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 20 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>1980</p>
                                                            </div>
                                                        </div>
                                                        <div className="totalSpaceBot" style={{ display: "flex" }}>
                                                            <div style={{ marginRight: 10, width: 130 }}>
                                                                <p>
                                                                    <strong>Total CBM </strong>
                                                                </p>
                                                            </div>
                                                            <div style={{ width: 20 }}>
                                                                <strong>:</strong>
                                                            </div>
                                                            <div>
                                                                <p>10.800</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table> */}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default QuotaionPdf;
