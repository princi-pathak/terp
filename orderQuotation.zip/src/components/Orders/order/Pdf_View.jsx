import React, { useRef } from "react";
import { useEffect, useId, useState } from "react";
import { useLocation } from "react-router-dom";
// import { usePDF } from "react-to-pdf";
import logo from "../../../assets/logoT.jpg";
import axios from "axios";
import { useQuery } from "react-query";
import { API_BASE_URL } from "../../../Url/Url";
import "./PdfSec.css";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import html2canvas from "html2canvas";
export const Pdf_View = () => {
  const [companyAddress, setCompanyAddress] = useState("");
  const [data, setData] = useState("");
  const [allData, setAllData] = useState("");
  // const [totalDetails, setTotalDetails] = useState("");
  const [tableData, setTableData] = useState([]);
  const [messageSet, setMassageSet] = useState("");

  const location = useLocation();
  const { from } = location.state || {};
  console.log(from);
  console.log(from?.order_id);
  const delivery = () => {
    axios
      .post(`${API_BASE_URL}/pdf_delivery_by  `, {
        order_id: from?.order_id,
      })
      .then((response) => {
        console.log(response.status);
      })
      .catch((error) => {
        console.log(error);
        if (error.response.status === 400) {
          setMassageSet(error.response.data.message);
        }
        // toast.error("Network Error", {
        //   autoClose: 1000,
        //   theme: "colored",
        // });
        return false;
      });
  };
  const tableDataAll = () => {
    axios
      .post(`${API_BASE_URL}/orderPdfTable`, {
        order_id: from?.order_id,
      })
      .then((response) => {
        console.log(response);

        setTableData(response?.data?.results);
      })
      .catch((error) => {
        console.log(error);
        // toast.error("Network Error", {
        //   autoClose: 1000,
        //   theme: "colored",
        // });
        return false;
      });
  };
  const { data: totalDetails, refetch: getSummary } = useQuery(
    `getOrderSummary?quote_id=${from?.order_id}`,
    {
      enabled: !!from?.order_id,
    }
  );
  console.log(totalDetails);
  const pdfAllData = () => {
    axios
      .post(`${API_BASE_URL}/GetOrderPdfDetails`, {
        order_id: from?.order_id,
      })
      .then((response) => {
        console.log(response.data);
        setCompanyAddress(response?.data?.Company_Address);
        setData(response?.data?.orderResults);
        setAllData(response?.data);

        // setTotalDetails(response?.data?.totalDetails);
      })
      .catch((error) => {
        console.log(error);
        toast.error("Network Error", {
          autoClose: 1000,
          theme: "colored",
        });
        return false;
      });
  };

  useEffect(() => {
    pdfAllData();
    tableDataAll();
    delivery();
    getSummary();
  }, []);

  function formatDate(date) {
    const day = date.getDate().toString().padStart(2, "0"); // Adds leading zero if needed
    const month = (date.getMonth() + 1).toString().padStart(2, "0"); // Month is 0-based, add 1
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  }
  //  formatter
  const tableRef = useRef();
  const handleDownloadPdf = () => {
    const input = tableRef.current;
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();

      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      const pageHeight = pdf.internal.pageSize.getHeight();
      const totalPages = Math.ceil(pdfHeight / pageHeight);

      for (let i = 0; i < totalPages; i++) {
        pdf.addImage(imgData, "PNG", 0, -(pageHeight * i), pdfWidth, pdfHeight);

        pdf.setFontSize(8);
        pdf.text(
          `This document is ${totalPages} Pages (${
            i + 1
          } out of ${totalPages})`,
          pdfWidth - 57,
          10 // Adjust this value if you want it lower or higher from the top
        );

        if (i < totalPages - 1) {
          pdf.addPage();
        }
      }

      const filename = `${from?.Order_number || "default"} Customs ${formatDate(
        new Date()
      )}.pdf`;
      pdf.save(filename);
    });
  };

  // Create a number formatter.
  const formatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 0,
  });
  const newFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 4,
  });
  const newFormatter1 = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 3,
  });
  const formatDate1 = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-GB"); // 'en-GB' format is DD/MM/YYYY
  };
  return (
    <>
      <button
        onClick={handleDownloadPdf}
        type="button"
        className="btn btn-primary"
      >
        Download
      </button>

      <div
        size="A4"
        style={{ background: "#fff", width: "800px" }}
        ref={tableRef}
      >
        <div>
          <table
            className="headerPdf"
            style={{ width: "100%", padding: "20px", display: "block" }}
          >
            <tbody className="pdfCenter" style={{ width: "100%" }}>
              <tr style={{ width: "100%" }}>
                <td style={{ width: "100%", display: "block" }}>
                  <table style={{ width: "100%" }}>
                    <tbody>
                      <tr style={{ width: "100%" }}>
                        <td style={{ padding: 0, width: "100%" }}>
                          <div style={{ display: "flex", width: "100%" }}>
                            <div className="logoArea" style={{ width: 65 }}>
                              <img
                                style={{ height: 55 }}
                                crossorigin="anonymous"
                                src={companyAddress.logo}
                              />
                            </div>
                            <div>
                              <div className="addressPara">
                                <div style={{ padding: "0px 2px 0px 0px" }}>
                                  <h5>{companyAddress?.Line_1}</h5>
                                  <p style={{ marginTop: 2 }}>
                                    {companyAddress?.Line_2}
                                  </p>
                                  <p style={{ marginTop: 2 }}>
                                    {companyAddress?.Line_3}
                                  </p>
                                  <p style={{ marginTop: 2 }}>
                                    {companyAddress?.Line_4}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table className="packList">
                    <tbody>
                      <tr>
                        <td
                          style={{
                            textAlign: "center",
                            color: "#1b2245",
                            fontSize: "14px",
                            fontWeight: "600",
                            color: "#ffff !important",
                            position: "relative",
                            top: "-3px",
                          }}
                        >
                          Packing List / Invoice
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table style={{ width: "100%" }} className="awb">
                    <tbody>
                      <tr>
                        <td>
                          <div style={{ display: "flex" }}>
                            <div style={{ width: "100%" }}>
                              <table style={{ width: "100%" }}>
                                <tbody>
                                  <tr>
                                    <td style={{ padding: "0px" }}>
                                      <div style={{ display: "flex" }}>
                                        <div
                                          className="totalSpaceBot"
                                          style={{ width: "50%" }}
                                        >
                                          <div
                                            style={{
                                              display: "flex",
                                            }}
                                          >
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Order</strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>{data?.order_number}</p>
                                            </div>
                                          </div>
                                          <div
                                            style={{
                                              display: "flex",
                                            }}
                                          >
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Loading Date</strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>
                                                {" "}
                                                <p>
                                                  {formatDate1(data?.load_date)}
                                                </p>
                                              </p>
                                            </div>
                                          </div>
                                          <div
                                            style={{
                                              display: "flex",
                                            }}
                                          >
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Shipment Ref</strong>{" "}
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>{from?.Shipment_ref}</p>
                                            </div>
                                          </div>
                                          {/* <div
                                            style={{
                                              display: "flex",
                                            }}
                                          >
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Customer Ref</strong>{" "}
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>{from?.Customer_ref}</p>
                                            </div>
                                          </div> */}

                                          <div
                                            style={{
                                              display: "flex",
                                            }}
                                          >
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong
                                                  style={{ color: "#fff" }}
                                                >
                                                  sdfdsf
                                                </strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong></strong>
                                            </div>
                                            <div>
                                              <p style={{ color: "#fff" }}>
                                                dfsdfsfsf
                                              </p>
                                            </div>
                                          </div>
                                        </div>
                                        <div
                                          className="totalSpaceBot"
                                          style={{ width: "50%" }}
                                        >
                                          <div
                                            style={{
                                              display: "flex",
                                            }}
                                          >
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>AWB/BL</strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>
                                                {
                                                  allData?.freightDetailsResults
                                                    ?.awb
                                                }
                                              </p>
                                            </div>
                                          </div>
                                          <div
                                            style={{
                                              display: "flex",
                                            }}
                                          >
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Ship Date</strong>
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>
                                                {formatDate1(
                                                  allData?.freightDetailsResults
                                                    ?.ship_date
                                                )}
                                              </p>
                                            </div>
                                          </div>
                                          <div
                                            style={{
                                              display: "flex",
                                            }}
                                          >
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong>Delivery By</strong>{" "}
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong>:</strong>
                                            </div>
                                            <div>
                                              <p>{messageSet}</p>
                                            </div>
                                          </div>
                                          <div
                                            style={{
                                              display: "flex",
                                            }}
                                          >
                                            <div
                                              style={{
                                                marginRight: 10,
                                                width: 100,
                                              }}
                                            >
                                              <p>
                                                <strong
                                                  style={{ color: "#fff" }}
                                                >
                                                  Delivery By
                                                </strong>{" "}
                                              </p>
                                            </div>
                                            <div style={{ width: 40 }}>
                                              <strong style={{ color: "#fff" }}>
                                                :
                                              </strong>
                                            </div>
                                            <div>
                                              <p style={{ color: "#fff" }}>
                                                O-202309045
                                              </p>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table className="billTo">
                    <tr>
                      <td>
                        <div
                          style={{
                            display: "flex",
                          }}
                        >
                          <div
                            style={{
                              marginRight: 10,
                              width: 100,
                            }}
                          >
                            <p>
                              <strong style={{ fontWeight: "700" }}>
                                Invoice to
                              </strong>
                            </p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div
                          style={{
                            display: "flex",
                          }}
                        >
                          <div
                            style={{
                              marginRight: 10,
                            }}
                          >
                            <p>
                              <strong style={{ fontWeight: "700" }}>
                                Consignee Details
                              </strong>
                            </p>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </table>
                  <table
                    style={{
                      width: "100%",
                    }}
                    className="barton"
                  >
                    <tbody>
                      <tr>
                        <td style={{ padding: "0px " }}>
                          <div style={{ display: "flex", padding: "0px 0px" }}>
                            <div style={{ width: "50%", paddingRight: 5 }}>
                              <p>{allData?.clientResults?.client_name}</p>
                              <p>{allData?.clientResults?.client_address}</p>
                            </div>
                            <div style={{ width: "50%" }}>
                              <p>{allData?.consigneeResults?.consignee_name}</p>
                              <p>
                                {allData?.consigneeResults?.consignee_address}
                              </p>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table
                    className="tableBorder tableDetail"
                    style={{ width: "100%", padding: 2 }}
                  >
                    <tbody>
                      <tr className="darkTh">
                        <th
                          style={{
                            textAlign: "center",
                            width: 20,
                          }}
                        >
                          <p> #</p>
                        </th>
                        <th style={{ textAlign: "center" }}>
                          <p>Item Detail</p>
                        </th>
                        <th style={{ textAlign: "center" }}>
                          <p> HS Code</p>
                        </th>
                        <th
                          style={{
                            textAlign: "center",
                            width: 75,
                          }}
                        >
                          <p>QTY</p>
                        </th>
                        <th
                          style={{
                            width: 75,
                            textAlign: "center",
                          }}
                        >
                          <p>UNIT</p>
                        </th>
                        <th
                          style={{
                            textAlign: "center",
                            width: 75,
                          }}
                        >
                          <p>BOX</p>
                        </th>
                        <th
                          style={{
                            textAlign: "center",
                            width: 85,
                          }}
                        >
                          <p>FOB (THB)</p>
                        </th>
                      </tr>

                      {tableData?.map((item, i) => {
                        return (
                          <tr className="itemData">
                            <td
                              style={{
                                textAlign: "center",
                              }}
                            >
                              <p> {i + 1}</p>
                            </td>
                            <td>
                              <p> {item.itf_th}</p>
                            </td>
                            <td
                              style={{
                                textAlign: "right",
                              }}
                            >
                              <p>{item.HS_CODE}</p>
                            </td>
                            <td
                              style={{
                                textAlign: "right",
                              }}
                            >
                              <p> {newFormatter1.format(item.Net_Weight)}</p>
                            </td>
                            <td
                              style={{
                                textAlign: "center",
                              }}
                            >
                              <p> KG</p>
                            </td>
                            <td
                              style={{
                                textAlign: "right",
                              }}
                            >
                              <p> {item.Boxes}</p>
                            </td>
                            <td
                              style={{
                                textAlign: "right",
                              }}
                            >
                              <p>{newFormatter.format(item.FOB)}</p>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  <table style={{ marginTop: 5, width: "100%" }}>
                    <tbody>
                      <tr>
                        <td style={{ padding: 0 }}>
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            <div className="totalSpaceBot">
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 115 }}>
                                  <p>
                                    <strong>Total </strong>
                                  </p>
                                </div>
                                <div style={{ width: 30 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>
                                    {totalDetails?.Total_Box} Boxes /
                                    {totalDetails?.Items} Item{" "}
                                  </p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 115 }}>
                                  <p>
                                    <strong>Total Net Weight </strong>{" "}
                                  </p>
                                </div>
                                <div style={{ width: 30 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>
                                    {formatter.format(totalDetails?.Net_Weight)}
                                  </p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 115 }}>
                                  <p>
                                    <strong>Total Gross Weight </strong>
                                  </p>
                                </div>
                                <div style={{ width: 30 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>{totalDetails?.Gross_weight}</p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 115 }}>
                                  <p>
                                    <strong>Total CBM </strong>
                                  </p>
                                </div>
                                <div style={{ width: 30 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>{totalDetails?.CBM}</p>
                                </div>
                              </div>
                            </div>
                            <div
                              className="totalSpaceBot"
                              style={{ marginLeft: 10 }}
                            >
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 90 }}>
                                  <p>
                                    <strong>Total Packages</strong>
                                  </p>
                                </div>
                                <div style={{ width: 20 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p> {totalDetails?.Total_Box}</p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 90 }}>
                                  <p>
                                    <strong>FOB (THB) </strong>
                                  </p>
                                </div>
                                <div style={{ width: 20 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>{formatter.format(totalDetails?.FOB)}</p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 90 }}>
                                  <p>
                                    <strong>Air Freight </strong>
                                  </p>
                                </div>
                                <div style={{ width: 20 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>
                                    {formatter.format(totalDetails?.Freight)}
                                  </p>
                                </div>
                              </div>
                              <div style={{ display: "flex" }}>
                                <div style={{ marginRight: 10, width: 90 }}>
                                  <p>
                                    <strong>Exchange Rate </strong>
                                  </p>
                                </div>
                                <div style={{ width: 20 }}>
                                  <strong>:</strong>
                                </div>
                                <div>
                                  <p>{from?.fx_rate}</p>
                                </div>
                              </div>
                            </div>
                            <div>
                              <div
                                style={{ position: "relative", top: "-3px" }}
                              >
                                <table className="unsetAll">
                                  <tr>
                                    <td>
                                      <div className="toatalThbTwo">
                                        <div>
                                          <strong>Total THB</strong>
                                        </div>
                                        <div>
                                          <p>
                                            {" "}
                                            {formatter.format(
                                              totalDetails?.total_THB
                                            )}
                                          </p>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                </table>
                              </div>
                              <div style={{ marginTop: "-7px" }}>
                                <table className="unsetAll">
                                  <tr>
                                    <td style={{ color: "#fff" }}>
                                      <div className="toatalThbTwo">
                                        <div>
                                          <strong>
                                            Total{" "}
                                            {allData?.currencyResults?.currency}
                                          </strong>
                                        </div>
                                        <div>
                                          <p>
                                            {" "}
                                            {formatter.format(
                                              totalDetails?.total_USD
                                            )}
                                          </p>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                </table>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table style={{ width: "100%" }}>
                    <tbody>
                      {from?.NOTES ? (
                        <tr>
                          <td style={{ padding: 0 }}>
                            <h3 style={{ fontWeight: 700 }}>Note :</h3>
                            <div className="noteRe">
                              <p>{from?.NOTES}</p>
                            </div>
                          </td>
                        </tr>
                      ) : (
                        ""
                      )}
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};
